This version of GEOTEC has been discontinued, it is easier to make a game in than GEOTEC_1.2 but it is still a complete mess. I completely rewrote the engine and editor so that you could have an almost infinate amount of tiles.

Controls:

- using Ctrl + G + W does something special
- the Orange button spawns flashing rainbow tiles at random X and Y positions
- the Green button allows you to place a tile
- the Blue button toggles the gridlines but you need to be very careful about   how you place tiles for them to be inside the gridlines.
- the Pink button saves the map
- the text in the Left-Hand corner can be clicked to change which type of tile   you are using
- WASD to move
- Right click to place tiles, Left click to remove tiles

Suggestions:

- Add more tile types some with textures
- make an rpg or platformer
- smooth out the collision
- just build maps for the heck of it
- add some sound

I hope you have fun playing ooplocks

 - Lemmingsishard, UPGSOFTWARE, WIZARDSTUDIOS - 20.6.24