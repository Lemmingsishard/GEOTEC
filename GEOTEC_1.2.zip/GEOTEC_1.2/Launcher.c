#include <stdio.h>
#include <stdlib.h>

int main() {
    system("python GEOTEC_1_2.py");
    return 0;
}